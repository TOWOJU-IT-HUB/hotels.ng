
        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="content-page">
            <!-- Start content -->
            <div class="content">

                <div class="container-fluid">
                    <div class="page-title-box">
                    </div>                    
                    <!-- // Page contents starts here -->
                    
                </div>
                <!-- container-fluid -->

            </div>
            <!-- content -->