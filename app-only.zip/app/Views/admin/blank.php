<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="content-page">
    <?php $uri = service('uri') ?>
    <div class="content">
        <div class="container-fluid">
            <div class="page-title-box">
            </div>
            <!-- end page-title -->
            <div class="row card card-body">
                <div class="col-12">
                    
                </div>
            </div>
            <!-- End row -->
        </div>
        <!-- container-fluid -->
    </div>