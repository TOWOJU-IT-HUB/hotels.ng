<?php

return [
    'site_title' => conf['site_title'],
];
