<?php

return [
    'site_title'    => conf['site_title'],
    'email'         =>  'Email',
    'password'      =>  'Contraseña',
    'forgot'        =>  'Olvidó',
    'lastname'      =>  'Apellido',
    'firstname'     =>  'Primer nombre',
    'register'      =>  'Registrarse',
    'login'         =>  'Acceso',
    'home'          =>  'Hogar',
    'dashboard'     =>  'Tablero',
    'services'      =>  'Servicios',
    'blog'          =>  'Blog',
    'other_pages'   =>  'Otras Paginas',
    'contact_us'    =>  'Contáctenos',
    'signin'        =>  'Iniciar sesión',
    'password_recovery'=>'Recuperación de contraseña',
];
